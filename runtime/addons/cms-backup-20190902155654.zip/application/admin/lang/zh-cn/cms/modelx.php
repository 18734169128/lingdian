<?php

return [
    'Name'       => '模型名称',
    'Table'      => '表名',
    'Fields'     => '字段列表',
    'Channeltpl' => '栏目页模板',
    'Listtpl'    => '列表页模板',
    'Showtpl'    => '详情页模板',
    'Main list'  => '主表列表',
    'Addon list' => '副表列表',
    'Duplicate'  => '复制模型',
    'Createtime' => '创建时间',
    'Updatetime' => '更新时间',
    'Setting'    => '配置'
];
