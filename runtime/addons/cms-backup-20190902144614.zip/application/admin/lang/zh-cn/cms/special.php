<?php

return [
    'Title'                  => '标题',
    'Tag_ids'                => '标签ID集合',
    'Flag'                   => '标志',
    'Label'                  => '标签',
    'Image'                  => '图片',
    'Banner'                 => 'Banner图片',
    'Diyname'                => '自定义名称',
    'Keywords'               => '关键字',
    'Description'            => '描述',
    'Intro'                  => '专题介绍',
    'Views'                  => '浏览次数',
    'Comments'               => '评论次数',
    'Createtime'             => '添加时间',
    'Updatetime'             => '更新时间',
    'Template'               => '专题模板',
    'The data already exist' => '已经存在',
    'Status'                 => '状态'
];
