<?php

return [
    'Type'             => '类型',
    'Name'             => '名称',
    'Table'            => '表名',
    'Keywords'         => '关键字',
    'Description'      => '描述',
    'Successtips'      => '成功提交提示文字',
    'Redirecturl'      => '成功后跳转链接',
    'Diyname'          => '自定义名称',
    'Needlogin'        => '是否需要登录',
    'Formtpl'          => '表单模板',
    'Createtime'       => '添加时间',
    'Updatetime'       => '更新时间',
    'Status'           => '状态',
    'Redirecturl tips' => '为空时将跳转到CMS首页'
];
