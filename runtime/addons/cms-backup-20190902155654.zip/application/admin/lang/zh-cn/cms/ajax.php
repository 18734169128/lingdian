<?php

return [
    'Please input your content' => '请输入检测内容',
    'The content is not legal'  => '发现违禁词',
    'The content is legal'      => '未发现违禁词',
];